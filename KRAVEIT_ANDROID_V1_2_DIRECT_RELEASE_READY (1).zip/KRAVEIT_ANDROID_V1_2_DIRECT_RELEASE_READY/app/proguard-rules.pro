# KRAVEIT Android V1 currently uses platform WebView APIs only.
