# KRAVEIT Android V1.1 — APK build

This project is ready for Android Studio or a GitHub Actions cloud build.

## Fastest cloud build
1. Create a private GitHub repository.
2. Upload the contents of this project to the repository root.
3. Open the repository's **Actions** tab.
4. Run **Build KRAVEIT Android APK** (or push to `main`).
5. Open the completed run and download the artifact named **KRAVEIT-Android-V1.1-debug**.
6. Extract the artifact and install `app-debug.apk` on an Android phone.

The debug APK is for testing. Do not publish it to Google Play.

## Play Store stage
After phone testing passes, configure a private release signing key and build an Android App Bundle (`.aab`). Never commit the keystore or passwords to the repository.
