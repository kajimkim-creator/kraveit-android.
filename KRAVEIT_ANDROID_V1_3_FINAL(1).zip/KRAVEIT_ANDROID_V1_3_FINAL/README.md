# KRAVEIT Android V1.3

Official KRAVEIT customer Android app source package.

- Package: `ke.co.kraveit.app`
- Version: `1.3.0` (code 4)
- Minimum Android: API 24
- Target/compile SDK: API 36
- Website: `https://kraveit.netlify.app/`

## V1.3 highlight
The app can remember a returning customer's **name, phone, delivery band and delivery notes** on that phone and prefill future checkout forms. The customer opts in using **Remember my details on this phone** and can remove the profile using **Forget saved details**.

The feature does not save payment codes, payment details or exact GPS coordinates. It is a local convenience profile, not a password-based customer account.

## Build
Use Java 17 and Gradle 8.11.1. The included GitHub Actions workflows support API 36 debug testing, unsigned release APK generation and signed AAB generation when signing secrets are configured.

Never commit a KRAVEIT `.jks` file or signing passwords to a public repository.
