plugins {
    id("com.android.application")
}

android {
    namespace = "ke.co.kraveit.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "ke.co.kraveit.app"
        minSdk = 24
        targetSdk = 36
        versionCode = 3
        versionName = "1.2.0"
        buildConfigField("String", "KRAVEIT_URL", "\"https://kraveit.netlify.app/\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    buildFeatures {
        buildConfig = true
    }
}
