# KRAVEIT Android V1.2 — Play Release Guide

This source keeps the customer app at version 1.2.0 (versionCode 3) and prepares it for Android API 36.

## Included release safeguards
- compileSdk 36 / targetSdk 36
- HTTPS-only WebView traffic
- mixed content blocked
- Safe Browsing enabled where supported
- geolocation permission is accepted only for https://kraveit.netlify.app
- Android backup disabled
- release keystore files ignored by Git
- signed AAB workflow expects GitHub Actions secrets; no signing key is stored in source

## Required GitHub secrets for signed AAB
- KRAVEIT_KEYSTORE_BASE64
- KRAVEIT_STORE_PASSWORD
- KRAVEIT_KEY_ALIAS
- KRAVEIT_KEY_PASSWORD

Never commit a .jks/.keystore file or passwords to the public repository.

## Build outputs
- Test APK: `gradle assembleDebug`
- Play bundle: `gradle bundleRelease` after signing environment variables are provided.

## Important
The app loads the live website at https://kraveit.netlify.app/, so website checkout/menu updates appear in the app without rebuilding the APK/AAB unless native Android code changes.
