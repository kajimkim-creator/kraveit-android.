# KRAVEIT Android V1.2

- Added a native bottom navigation bar: Home, Track, WhatsApp.
- Track opens the KRAVEIT order tracking screen directly inside the app.
- WhatsApp opens the customer's WhatsApp/browser externally.
- Improved offline fallback so bundled logo/assets can render reliably.
- Tightened in-app navigation to HTTPS KRAVEIT pages only.
- Kept the existing KRAVEIT website/backend, sequential order IDs, payment-first workflow and admin system unchanged.
- Version bumped to 1.2.0 (versionCode 3).
