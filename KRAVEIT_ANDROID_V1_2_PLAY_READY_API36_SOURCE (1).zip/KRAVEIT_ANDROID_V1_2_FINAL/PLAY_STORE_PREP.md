# KRAVEIT Android V1.2 — Play Store Preparation

This package is a Play-preparation copy of the tested KRAVEIT V1.2 Android app.

## Changes made
- compileSdk: 36
- targetSdk: 36
- Android Gradle Plugin: 8.10.1
- GitHub Actions Gradle: 8.11.1
- GitHub Actions installs Android platform 36

## Preserved
- applicationId: ke.co.kraveit.app
- versionName: 1.2.0
- versionCode: 3
- minSdk: 24
- KRAVEIT website URL and app behavior
- native Home / Track Order / WhatsApp navigation
- location handling, deep links, offline screen, branding

## Important
The source is ready for API 36 build testing. A Google Play submission still requires a release Android App Bundle (.aab) signed with a private upload key. Do not commit the upload keystore or its password to a public GitHub repository.
