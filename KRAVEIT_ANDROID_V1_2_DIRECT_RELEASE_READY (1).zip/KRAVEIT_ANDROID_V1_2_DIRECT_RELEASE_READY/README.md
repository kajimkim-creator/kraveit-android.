# KRAVEIT Android V1.2

Native Android customer app shell for KRAVEIT.

## Customer experience
- Official KRAVEIT launcher icon and splash branding
- KRAVEIT production ordering site inside a native Android WebView
- Native bottom navigation: Home, Track, WhatsApp
- Same Netlify backend and order database as the website
- Location support for delivery pin capture
- External phone, email, maps and WhatsApp links
- KRAVEIT `/t/...` tracking deep links can open in the app
- Branded offline fallback screen
- HTTPS-only production traffic

## Production URL
`https://kraveit.netlify.app/`

## Build
The included GitHub Actions workflow builds a debug APK automatically on pushes to `main` or manually with **Run workflow**.

In Android Studio, allow Gradle sync and choose **Build > Build APK(s)**.
For Google Play, generate and protect a release signing key and produce a signed AAB/APK.

## Important
The customer app does not expose the KRAVEIT admin portal. Admin remains a separate secured workflow.
