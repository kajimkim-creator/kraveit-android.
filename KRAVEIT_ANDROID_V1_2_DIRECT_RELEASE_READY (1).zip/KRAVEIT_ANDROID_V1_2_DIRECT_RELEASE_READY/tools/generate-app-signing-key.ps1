$ErrorActionPreference = "Stop"
Write-Host "KRAVEIT permanent app-signing key generator" -ForegroundColor Cyan
Write-Host "Keep the resulting keystore OFFLINE and NEVER commit it to GitHub." -ForegroundColor Yellow

$keytool = (Get-Command keytool -ErrorAction SilentlyContinue).Source
if (-not $keytool) {
  throw "keytool was not found. Install a JDK (Java 17 or newer) first."
}

$dest = Join-Path $PSScriptRoot "KRAVEIT_PRIVATE_SIGNING"
New-Item -ItemType Directory -Force -Path $dest | Out-Null
$ks = Join-Path $dest "kraveit-app-signing.jks"
if (Test-Path $ks) { throw "Signing keystore already exists at $ks. Refusing to overwrite it." }

Write-Host "You will be asked for a strong password. Save it in a password manager." -ForegroundColor Yellow
& $keytool -genkeypair -v -keystore $ks -storetype JKS -alias kraveit_app -keyalg RSA -keysize 4096 -sigalg SHA256withRSA -validity 10000 -dname "CN=KRAVEIT, OU=Mobile, O=KRAVEIT, L=Nairobi, ST=Nairobi, C=KE"
if ($LASTEXITCODE -ne 0) { throw "keytool failed" }

$cert = Join-Path $dest "kraveit-app-signing-certificate.pem"
& $keytool -exportcert -rfc -keystore $ks -alias kraveit_app -file $cert
if ($LASTEXITCODE -ne 0) { throw "Certificate export failed" }

Write-Host "Created:" -ForegroundColor Green
Write-Host "  $ks"
Write-Host "  $cert"
Write-Host "Back up the .jks in at least two offline locations." -ForegroundColor Yellow
