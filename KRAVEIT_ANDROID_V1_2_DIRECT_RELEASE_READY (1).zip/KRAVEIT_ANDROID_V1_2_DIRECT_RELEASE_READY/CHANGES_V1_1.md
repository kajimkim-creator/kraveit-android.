# KRAVEIT Android V1.1

- Uses the official KRAVEIT logo and splash branding.
- Loads the production KRAVEIT site at https://kraveit.netlify.app/.
- Added native page-loading progress indicator.
- Added online/offline detection and branded retry screen.
- Preserved geolocation support for customer delivery pins.
- Preserved external WhatsApp, telephone, email and map handling.
- Preserved KRAVEIT tracking deep links.
- HTTPS-only web traffic remains enforced.
- Added a GitHub Actions workflow capable of producing a test APK in the cloud.
- App version bumped to 1.1.0 (versionCode 2).
