# KRAVEIT Android V1.3

Version: 1.3.0 (versionCode 4)

## Returning-customer convenience
- Added **Remember my details on this phone** to KRAVEIT web checkout when used inside the Android app.
- Saved fields: customer name, phone number, delivery band and delivery notes/address text.
- Saved details automatically prefill the next app checkout and remain editable.
- Added **Forget saved details** so the customer can remove the stored profile from the device.
- No KRAVEIT account or password is required to use this convenience feature.

## Privacy safeguards
- M-Pesa confirmation codes are never saved by the app profile feature.
- Payment details are never stored by the app profile feature.
- Exact GPS coordinates are not persisted in the saved profile.
- App backup remains disabled, so the profile is not included in normal Android cloud backups.
- Clearing app data or uninstalling the app removes the locally saved profile.

## Preserved from V1.2
- Application ID: `ke.co.kraveit.app`
- Official KRAVEIT branding, icon and splash screen
- Home / Track / WhatsApp native navigation
- Production KRAVEIT WebView
- Location permission flow
- HTTPS-only internal navigation
- Order tracking deep links
- External call/email/WhatsApp handling
- Offline fallback
- API 36 target

This is a customer convenience release. It does not add admin credentials, payment secrets or a customer password system.
