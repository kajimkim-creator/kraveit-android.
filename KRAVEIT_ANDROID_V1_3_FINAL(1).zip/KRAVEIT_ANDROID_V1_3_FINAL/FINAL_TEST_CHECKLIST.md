# KRAVEIT Android V1.3 — Final Test Checklist

## Build/version
- [ ] App builds with Java 17 / Gradle 8.11.1 / Android API 36
- [ ] Application ID is `ke.co.kraveit.app`
- [ ] Version is 1.3.0 / versionCode 4
- [ ] Permanent KRAVEIT release signing key is used for public release

## Core app
- [ ] Home opens KRAVEIT production site
- [ ] Track opens order tracking
- [ ] WhatsApp opens externally
- [ ] Phone/email links open externally
- [ ] Offline page appears when internet is unavailable
- [ ] Location prompt works only for KRAVEIT HTTPS origin

## Remember-my-details feature
- [ ] Open app checkout and confirm **Remember my details on this phone** appears
- [ ] Enter name, phone, delivery band and delivery notes
- [ ] Tick Remember and place/test an order
- [ ] Reopen app checkout and confirm the fields are prefilled
- [ ] Edit saved values and confirm later checkout uses the updated values
- [ ] Use **Forget saved details** and confirm later checkout is blank/default
- [ ] Confirm M-Pesa confirmation code is never prefilled or stored
- [ ] Confirm a new location pin must be supplied when needed; exact GPS coordinates are not persisted

## Upgrade behavior
- [ ] Install release-signed V1.3 over release-signed V1.2 and confirm upgrade succeeds
- [ ] If V1.2 on the device was a debug build, uninstall it before installing the permanent release-signed app
