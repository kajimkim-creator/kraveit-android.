# KRAVEIT V1.3 — Safe Direct APK Release

This process is intentionally split into two trust zones:

1. **GitHub Actions builds an unsigned release APK.** No permanent app-signing private key is stored in the public repository or CI.
2. **The final APK is signed on the owner's computer** using KRAVEIT's permanent app-signing key.

## Why this matters
Android accepts updates only when they are signed by the expected signing identity. KRAVEIT's direct-download APK should use one permanent app-signing key. When Play Store launch happens later, configure Play App Signing to use a copy of that same app-signing key if you want direct-install users to be able to move to/update from the Play-distributed build without a signature mismatch.

## Phase A — Build unsigned APK
Run the included GitHub Actions workflow:
`.github/workflows/android-direct-apk-unsigned.yml`

Download the artifact named:
`KRAVEIT-V1.3-unsigned-release-apk`

## Phase B — Create the permanent app-signing key locally
On the Windows PC that will own the key, run:
`tools/generate-app-signing-key.ps1`

Never upload `kraveit-app-signing.jks` to the public repository. Keep at least two offline backups and store the password in a password manager.

## Phase C — Sign and verify locally
Install Android SDK Build Tools, then run:
`tools/sign-direct-apk.ps1 -UnsignedApk "C:\path\to\app-release-unsigned.apk"`

The script creates:
- `KRAVEIT-V1.3.0-release-signed.apk`
- a `.sha256.txt` checksum

It also runs `apksigner verify --verbose --print-certs` before declaring success.

## Phase D — Publish safely
Only after signature verification:
- host the signed APK over HTTPS on the official KRAVEIT website;
- publish a dedicated `/download-app.html` page;
- show version, package name, file size, SHA-256 checksum, privacy-policy link, and install instructions;
- never tell users to disable Google Play Protect;
- submit the download page (not the raw APK URL) to Google Search Console.

## Play Store later
For Play App Signing, use a separate **upload key** for Play uploads. The permanent direct-distribution app-signing key should stay offline. Before the first Play release, choose the Play signing option that allows KRAVEIT to provide its existing app-signing key if continuity with the direct APK is required.
