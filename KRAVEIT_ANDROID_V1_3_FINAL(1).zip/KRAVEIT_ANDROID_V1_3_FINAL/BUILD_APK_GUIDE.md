# KRAVEIT Android V1.3 — APK build

This project is ready for Android Studio or GitHub Actions.

## Cloud build
1. Put the **contents of this project** at the repository root.
2. Open **Actions**.
3. Run **Build KRAVEIT V1.3 Unsigned Release APK** for the direct-release APK, or the API 36 test workflow for a debug test build.
4. Download the generated artifact after the workflow succeeds.
5. Sign the release APK with KRAVEIT's permanent release key before public distribution.

## Important
- Application ID: `ke.co.kraveit.app`
- Version: `1.3.0` / versionCode `4`
- Target/compile SDK: `36`
- Java: `17`
- Gradle: `8.11.1`
- Never commit the `.jks` file or signing passwords to a public repository.
- A debug APK is for testing only and should not be distributed as the final customer build.
