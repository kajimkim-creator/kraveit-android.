# KRAVEIT Android V1.3 — Final Customer App Package

Version: **1.3.0**  
Version code: **4**  
Application ID: **ke.co.kraveit.app**  
Target SDK: **36**

V1.3 keeps the V1.2 customer app experience and adds a lightweight returning-customer profile for checkout.

When checkout is opened inside the KRAVEIT Android app, customers can choose **Remember my details on this phone**. The app then pre-fills their name, phone number, delivery band and delivery notes on future orders. Customers can edit the details at any time or remove them with **Forget saved details**.

The feature deliberately does **not** save M-Pesa confirmation codes, payment information or exact GPS coordinates. No customer password/account is required.

The rest of the app remains unchanged: KRAVEIT production website, native Home/Track/WhatsApp navigation, location support, tracking deep links, HTTPS-only rules and offline fallback.

The app continues to load `https://kraveit.netlify.app/`; therefore the latest website checkout experience becomes available in the app when that website version is published.
