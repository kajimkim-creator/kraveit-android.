# KRAVEIT V1.2 Direct Release Safety Additions

No customer-facing features changed.

Added:
- unsigned release APK build path for CI;
- permanent signing-key generation script for the owner's computer;
- offline APK signing and verification script;
- SHA-256 checksum generation;
- direct APK release guide;
- explicit protection against putting the permanent app-signing key in the public repository.

App identity remains:
- applicationId: `ke.co.kraveit.app`
- versionName: `1.2.0`
- versionCode: `3`
- targetSdk / compileSdk: `36`
