# KRAVEIT Android V1.2 — Final Test Checklist

Before release, test the compiled APK on a real Android phone:

1. App installs and shows the KRAVEIT icon.
2. App opens with the KRAVEIT splash/loading screen.
3. Home loads the live KRAVEIT customer site.
4. Menu and K-MOSA pages open correctly.
5. Add-to-cart and extras work.
6. Delivery selection and customer details work.
7. Order creation succeeds and returns a sequential KR order number.
8. Full-payment-before-preparation message is shown.
9. Tracking opens from the bottom navigation and order links.
10. WhatsApp opens the KRAVEIT business number.
11. Location permission works when requested.
12. Offline/retry screen appears when internet is unavailable.
13. Back navigation does not trap the user.
14. Admin portal is not exposed as a normal customer navigation item.
15. Existing web admin receives the order and can move it through Paid → Kitchen → Dispatched → Delivered.

If all checks pass, use this V1.2 build as the first Android release candidate.
