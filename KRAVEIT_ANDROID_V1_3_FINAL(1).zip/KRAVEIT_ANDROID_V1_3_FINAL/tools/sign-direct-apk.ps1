param(
  [Parameter(Mandatory=$true)][string]$UnsignedApk,
  [string]$Keystore = "$PSScriptRoot\KRAVEIT_PRIVATE_SIGNING\kraveit-app-signing.jks"
)
$ErrorActionPreference = "Stop"

if (-not (Test-Path $UnsignedApk)) { throw "Unsigned APK not found: $UnsignedApk" }
if (-not (Test-Path $Keystore)) { throw "Keystore not found: $Keystore" }

$androidHome = $env:ANDROID_HOME
if (-not $androidHome) { $androidHome = $env:ANDROID_SDK_ROOT }
if (-not $androidHome) { throw "ANDROID_HOME / ANDROID_SDK_ROOT is not set. Install Android SDK Build Tools first." }

$apksigner = Get-ChildItem -Path (Join-Path $androidHome "build-tools") -Filter "apksigner.bat" -Recurse | Sort-Object FullName -Descending | Select-Object -First 1
if (-not $apksigner) { throw "apksigner.bat not found under Android SDK build-tools." }

$out = Join-Path (Split-Path $UnsignedApk) "KRAVEIT-V1.3.0-release-signed.apk"
& $apksigner.FullName sign --ks $Keystore --ks-key-alias kraveit_app --out $out $UnsignedApk
if ($LASTEXITCODE -ne 0) { throw "APK signing failed" }

& $apksigner.FullName verify --verbose --print-certs $out
if ($LASTEXITCODE -ne 0) { throw "APK signature verification failed" }

$hash=(Get-FileHash -Algorithm SHA256 $out).Hash.ToLower()
$hashFile="$out.sha256.txt"
"$hash  $(Split-Path $out -Leaf)" | Set-Content -Encoding ascii $hashFile

Write-Host "Signed and verified:" -ForegroundColor Green
Write-Host "  $out"
Write-Host "SHA-256:" -ForegroundColor Green
Write-Host "  $hash"
