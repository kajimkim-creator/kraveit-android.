# KRAVEIT V1.2 Play-release-ready changes

No menu, pricing, cart, checkout, payment, tracking, WhatsApp, or admin business logic was changed.

Native Android changes only:
- target/compile SDK moved from 35 to 36
- Android Gradle Plugin moved to 8.10.1
- release signing configuration added through environment variables
- signed AAB GitHub Actions workflow added
- API 36 debug-test workflow added
- WebView Safe Browsing enabled on supported Android versions
- location/geolocation prompts restricted to the KRAVEIT production HTTPS origin
- Android app backup disabled
- sensitive signing files excluded by .gitignore

App version remains 1.2.0, versionCode 3.
