# KRAVEIT Android V1.2 — Final Release Candidate

Status: Feature-frozen for V1.2.

Included:
- Official KRAVEIT branding and app icon
- Branded splash/loading experience
- Customer ordering experience using the KRAVEIT production web app
- Native bottom navigation: Home, Track Order, WhatsApp
- Location support
- WhatsApp, phone and email handling
- Order tracking deep links
- HTTPS-only navigation/security rules
- Offline/retry handling
- GitHub Actions workflow for APK build
- Version 1.2.0

Business logic remains on the existing KRAVEIT backend. No admin credentials or backend secrets are bundled in the customer app.

V1.2 is now frozen: no more feature changes should be added before APK testing. Any later features should be V1.3 or a separate KRAVEIT Admin app.
